export const empleados = [
    {
        'noEmpleado': '99091234',
        'nombre':'Luis Enrique Moo', 
        'email':'luis.moo@coppel.com',
        'perfil':'programador',
        'rol':'admin'
    },
    {
        'noEmpleado': '99095678',
        'nombre':'Luis Alberto Beltran', 
        'email':'luis.beltran@coppel.com',
        'perfil':'programador',
        'rol':'admin'
    },
    {
        'noEmpleado': '99191234',
        'nombre':'Luis Angel', 
        'email':'luis.angel@coppel.com',
        'perfil':'programador',
        'rol':'user'
    },
    {
        'noEmpleado': '99095678',
        'nombre':'Luis Alberto Beltran', 
        'email':'luis.beltran@coppel.com',
        'perfil':'programador',
        'rol':'admin'
    },
    {
        'noEmpleado': '99191234',
        'nombre':'Luis Angel', 
        'email':'luis.angel@coppel.com',
        'perfil':'programador',
        'rol':'user'
    },
    {
        'noEmpleado': '99095678',
        'nombre':'Luis Alberto Beltran', 
        'email':'luis.beltran@coppel.com',
        'perfil':'programador',
        'rol':'admin'
    },
    {
        'noEmpleado': '99191234',
        'nombre':'Luis Angel', 
        'email':'luis.angel@coppel.com',
        'perfil':'programador',
        'rol':'user'
    },
    {
        'noEmpleado': '99095678',
        'nombre':'Luis Alberto Beltran', 
        'email':'luis.beltran@coppel.com',
        'perfil':'programador',
        'rol':'admin'
    },
    {
        'noEmpleado': '99191234',
        'nombre':'Luis Angel', 
        'email':'luis.angel@coppel.com',
        'perfil':'programador',
        'rol':'user'
    },
    {
        'noEmpleado': '99095678',
        'nombre':'Luis Alberto Beltran', 
        'email':'luis.beltran@coppel.com',
        'perfil':'programador',
        'rol':'admin'
    },
    {
        'noEmpleado': '99191234',
        'nombre':'Luis Angel', 
        'email':'luis.angel@coppel.com',
        'perfil':'programador',
        'rol':'user'
    },
    {
        'noEmpleado': '99095678',
        'nombre':'Luis Alberto Beltran', 
        'email':'luis.beltran@coppel.com',
        'perfil':'programador',
        'rol':'admin'
    },
    {
        'noEmpleado': '99191234',
        'nombre':'Luis Angel', 
        'email':'luis.angel@coppel.com',
        'perfil':'programador',
        'rol':'user'
    },
    {
        'noEmpleado': '99095678',
        'nombre':'Luis Alberto Beltran', 
        'email':'luis.beltran@coppel.com',
        'perfil':'programador',
        'rol':'admin'
    },
    {
        'noEmpleado': '99191234',
        'nombre':'Luis Angel', 
        'email':'luis.angel@coppel.com',
        'perfil':'programador',
        'rol':'user'
    },
    {
        'noEmpleado': '99095678',
        'nombre':'Luis Alberto Beltran', 
        'email':'luis.beltran@coppel.com',
        'perfil':'programador',
        'rol':'admin'
    },
    {
        'noEmpleado': '99191234',
        'nombre':'Luis Angel', 
        'email':'luis.angel@coppel.com',
        'perfil':'programador',
        'rol':'user'
    },
    {
        'noEmpleado': '99095678',
        'nombre':'Luis Alberto Beltran', 
        'email':'luis.beltran@coppel.com',
        'perfil':'programador',
        'rol':'admin'
    },
    {
        'noEmpleado': '99191234',
        'nombre':'Luis Angel', 
        'email':'luis.angel@coppel.com',
        'perfil':'programador',
        'rol':'user'
    },
    
]