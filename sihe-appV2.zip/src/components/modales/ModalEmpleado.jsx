import React from 'react'

export const ModalEmpleado = () => {
    return (
        <></>
    )
}
