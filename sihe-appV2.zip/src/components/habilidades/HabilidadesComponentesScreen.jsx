import React from 'react'

export const HabilidadesComponentesScreen = () => {
    return (
        <div>HabilidadesComponentesScreen</div>
    )
}
