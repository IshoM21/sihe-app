import React from 'react'

export const HabilidadesLenguajesScreen = () => {
    return (
        <div>HabilidadesLenguajesScreen</div>
    )
}
