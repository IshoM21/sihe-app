import React from 'react'

export const RequerimientosScreen = () => {
  return (
    <div>RequerimientosScreen</div>
  )
}
