import React from 'react'

export const Centros = () => {
    return (
        <div>Centros</div>
    )
}
