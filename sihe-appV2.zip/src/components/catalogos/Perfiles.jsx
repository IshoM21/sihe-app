import React from 'react'

export const Perfiles = () => {
    return (
        <div>Perfiles</div>
    )
}
