import React, { useContext } from 'react'
import { useNavigate } from 'react-router-dom';
import { AuthContext } from '../../auth/authContext';
import { types } from '../../types/types';
import logoCoppel from './LogoCoppel.jpg'
import '../login/LoginScreen.css'
import { useForm } from '../../hooks/useForm';

export const LoginScreen = () => {

    const navigate = useNavigate()

    const { dispatch } = useContext(AuthContext)
    const initialState = {
        email: '',
        password: ''
    };
    const [formValues, handleInputChange, reset] = useForm(initialState);
    const { email, password } = formValues

    // const handleLogin = () => {
    //     const action = {
    //         type: types.login,
    //         payload:{
    //             name: 'Jaime',
    //             rol: 'Admin'
    //         }
    //     }
    //     // const action = {
    //     //     type: types.login,
    //     //     payload:{
    //     //         name: 'Jaime',
    //     //         rol: 'Usuario'
    //     //     }
    //     // }
    //     dispatch(action)
    //     const lastPath = localStorage.getItem('lastPath') || '/dashboard/home'
    //     navigate(lastPath,{
    //         replace:true
    //     })
    const handleLogin = async (e) => {
        e.preventDefault()
        const data = { "idEmpleado": email, password }
        console.log(data);
        try {
            const url = `${process.env.REACT_APP_API_URL}/empleados/authenticate`
            console.log(url)
            const respuesta = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-type': 'application/json',
                },
                // body: JSON.stringify({ "username": "", "password": "123" })
                body: JSON.stringify(data)
            })
            var { token } = await respuesta.json()
            // console.log(JSON.stringify(datos));
            console.log(token);
            // return
        } catch (error) {
            console.log(JSON.stringify(error))
        }

        if (token !== "") {
            // console.log('asdsad');
            // var myHeaders = new Headers();
            // myHeaders.append("Authorization", "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI5ODc2NTQzMiIsImlhdCI6MTY1MzY5NjczMiwiZXhwIjoxNjUzNzE0NzMyfQ.MhG1eKPl2K6nBWtBUhhEygwR_C0GnF2Ot0ZKUwmlmn4");
            // myHeaders.append("Content-Type", "application/json");

            // var raw = JSON.stringify({
            //     "id": 98765432,
            //     "primerNombre": "ANA",
            //     "segundoNombre": "KAREN",
            //     "apellidoPaterno": "JUAREZ",
            //     "apellidoMaterno": "LOPEZ",
            //     "idCentro": {
            //         "id": 1,
            //         "descripcion": "Centro De Desarollo 1",
            //         "idCoordinacionDesarrollo": {
            //             "id": 1,
            //             "descripcion": "Centro 1"
            //         }
            //     },
            //     "idPerfil": {
            //         "idPerfil": 1,
            //         "descripcion": "Gerente",
            //         "su": true
            //     },
            //     "lugarPosicion": "",
            //     "correo": "enrique.tasf@coppel.com",
            //     "password": "anakaren",
            //     "externo": true
            // });

            // var requestOptions = {
            //     method: 'POST',
            //     headers: myHeaders,
            //     // mode: 'no-cors',
            //     body: raw,
            //     redirect: 'follow'
            // };

            // fetch("http://localhost:8080/api/private/v1/servfinancieros/sihe/empleados/empleadossave", requestOptions)
            //     .then(response => response.text())
            //     .then(result => console.log(result))
            //     .catch(error => console.log('error', error));
            // try{
            //     const datosEmpleado = {
            //         "id": 12340987,
            //         "primerNombre": "Pedro",
            //         "segundoNombre": "KAREN",
            //         "apellidoPaterno": "Mateos",
            //         "apellidoMaterno": "LOPEZ",
            //         "idCentro": {
            //             "id": 1,
            //             "descripcion": "Centro De Desarollo 1",
            //             "idCoordinacionDesarrollo": {
            //                 "id": 1,
            //                 "descripcion": "Centro 1"
            //             }
            //         },
            //         "idPerfil": {
            //             "idPerfil": 1,
            //             "descripcion": "Gerente",
            //             "su": true
            //         },
            //         "lugarPosicion": null,
            //         "correo": "enrique.tasf@coppel.com",
            //         "password": "anakaren",
            //         "externo": true
            //     }
            //     const url = `${process.env.REACT_APP_API_URL}/empleados/empleado/${email}`
            //     console.log(url);
            //     console.log(token)
            //     const respuesta = await fetch(url,{
            //         method: 'GET',
            //         headers: {
            //             // 'Content-type': 'application/json',
            //             'Accept': 'application/json',
            //             // "Content-Type": "application/x-www-form-urlencoded",
            //             'Content-Type': 'application/json',
            //             'Authorization': "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI5ODc2NTQzMiIsImlhdCI6MTY1MzY5NzEzMiwiZXhwIjoxNjUzNzE1MTMyfQ.zLwAHe73Cm_vJ4EcVKljdNeMYU7II3t3ngrtaCNXaXM"
            //         },
            //         // mode: 'no-cors',
            //         body: JSON.stringify(datosEmpleado)
            //     })
            //     const datos = await respuesta.json()
            //     console.log(JSON.stringify(datos))
            // }catch(error){
            //     console.log(JSON.stringify(error))
            // }
            var myHeaders = new Headers();
            myHeaders.append("Authorization", "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI5ODc2NTQzMiIsImlhdCI6MTY1MzY5NzEzMiwiZXhwIjoxNjUzNzE1MTMyfQ.zLwAHe73Cm_vJ4EcVKljdNeMYU7II3t3ngrtaCNXaXM");

            var raw = "";

            var requestOptions = {
                method: 'GET',
                headers: myHeaders,
                body: raw,
                redirect: 'follow'
            };

            fetch("http://localhost:8080/api/private/v1/servfinancieros/sihe/empleados/empleado/98765432", requestOptions)
                .then(response => response.text())
                .then(result => console.log(result))
                .catch(error => console.log('error', error));
            // const action ={}
            // dispatch(action)
            // const lastPath = localStorage.getItem('lastPath') || '/dashboard/home'
            // navigate(lastPath,{
            //     replace:true
            // })
        }

        // dispatch(action)
        // const lastPath = localStorage.getItem('lastPath') || '/dashboard/home'
        // navigate(lastPath,{
        // replace:true
        // })
    }


    return (
        <div className="vh-auto login mt-5" >
            <div className="container-fluid h-custom">
                <div className="login">
                    <div className="col-md-9 col-lg-6 col-xl-5  mx-auto">
                        <img src={logoCoppel} className="img-fluid" alt="Sample image" />
                    </div>
                    <div className="col-md-8 col-lg-6 col-xl-4 offset-xl-1 mx-auto">
                        <form>

                            <div className=" mb-4">
                                <label htmlFor="email" className='form-label'>Usuario</label>
                                <input type="email" className="form-control form-control-lg"
                                    placeholder="Ingresa tu usuario" name='email' id='email' value={email} onChange={handleInputChange} />
                            </div>

                            <div className="form-outline mb-3">
                                <label className="form-label" htmlFor="password">Contraseña</label>
                                <input type="password" name='password' id='password' className="form-control form-control-lg"
                                    placeholder="Contraseña" value={password} onChange={handleInputChange} />
                            </div>

                            <div className="d-flex justify-content-between align-items-center">
                                <div className="form-check mb-0">
                                </div>
                                <a href="#!" className="text-body">¿Olvidaste tu contraseña?</a>
                            </div>

                            <div className="text-center text-lg-start mt-4 pt-2">
                                <button type="button" className="btn btn-primary btn-lg" onClick={handleLogin}>
                                    Iniciar
                                </button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
            <div className="position-fixed w-100  bottom-0 d-flex flex-row flex-md-row text-center text-md-start justify-content-center py-4 px-4  px-xl-5 copyright ">
                <div className="text-white mb-3 mb-md-0 " >
                    Copyright © 2020. All rights reserved Prueba.
                </div>
            </div>
        </div>
    )
}
