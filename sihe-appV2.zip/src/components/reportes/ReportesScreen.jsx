import React from 'react'

export const ReportesScreen = () => {
  return (
    <div>ReportesScreen</div>
  )
}
